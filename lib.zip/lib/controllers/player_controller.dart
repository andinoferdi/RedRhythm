import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:just_audio/just_audio.dart' hide PlayerState;
import 'package:get_it/get_it.dart';
import '../../models/song.dart';
import '../../services/pocketbase_service.dart';
import '../../repositories/song_repository.dart';
import '../states/player_state.dart';
import 'play_history_controller.dart';

/// Provider for player controller
final playerControllerProvider =
    StateNotifierProvider<PlayerController, PlayerState>(
  (ref) => PlayerController(ref),
);

/// Controller for handling music playback
class PlayerController extends StateNotifier<PlayerState> {
  late final AudioPlayer _audioPlayer;
  final Ref ref;
  Timer? _positionTimer;
  String? _currentAudioUrl;
  bool _isDisposed = false;

  // Simple skip protection - minimal blocking
  DateTime? _lastSkipTime;
  static const Duration _minSkipInterval = Duration(milliseconds: 200);

  // Track player initialization state
  bool _isInitializing = false;

  PlayerController(this.ref) : super(PlayerState.initial()) {
    _initializeAudioPlayer();
  }

  /// Initialize audio player
  void _initializeAudioPlayer() {
    try {
      _isInitializing = true;
      _audioPlayer = AudioPlayer();
      _initAudioPlayer();
      _isInitializing = false;
    } catch (e) {
      debugPrint('Error initializing audio player: $e');
      _isInitializing = false;
      Future.delayed(const Duration(milliseconds: 300), () {
        if (!_isDisposed) {
          try {
            _audioPlayer = AudioPlayer();
            _initAudioPlayer();
          } catch (retryError) {
            debugPrint('Failed to reinitialize audio player: $retryError');
          }
        }
      });
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    _positionTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _initAudioPlayer() {
    // Listen to playback state changes
    _audioPlayer.playerStateStream.listen((playerState) {
      if (_isDisposed) return;

      final isPlaying = playerState.playing;
      final processingState = playerState.processingState;

      if (processingState == ProcessingState.loading ||
          processingState == ProcessingState.buffering) {
        state = state.copyWith(isBuffering: true);
      } else {
        state = state.copyWith(
          isPlaying: isPlaying,
          isBuffering: false,
        );

        if (processingState == ProcessingState.completed) {
          _handleSongCompletion();
        }
      }
    });

    // Listen to duration changes
    _audioPlayer.durationStream.listen((duration) {
      if (_isDisposed) return;

      if (duration != null && state.currentSong != null) {
        final updatedSong =
            _updateSongWithRealDuration(state.currentSong!, duration);
        state = state.copyWith(currentSong: updatedSong);
      }
    });

    // Position update timer
    _positionTimer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      if (!_isDisposed && _audioPlayer.playing) {
        _updatePosition();
      }
    });
  }

  /// Update current position
  void _updatePosition() {
    if (_isDisposed) return;

    try {
      final position = _audioPlayer.position;
      state = state.copyWith(currentPosition: position);
    } catch (e) {
      // Ignore position update errors
    }
  }

  /// Update song with actual audio duration
  Song _updateSongWithRealDuration(Song song, Duration realDuration) {
    if ((song.duration - realDuration).inSeconds.abs() > 5 ||
        song.durationInSeconds == 0) {
      _updateDurationInDatabase(song.id, realDuration.inSeconds);
      return song.copyWith(durationInSeconds: realDuration.inSeconds);
    }
    return song;
  }

  /// Update song duration in database
  Future<void> _updateDurationInDatabase(
      String songId, int durationInSeconds) async {
    try {
      final pbService = PocketBaseService();
      await pbService.pb.collection('songs').update(songId, body: {
        'duration': durationInSeconds,
      });
    } catch (e) {
      debugPrint('Error updating song duration in database: $e');
    }
  }

  /// Handle song completion
  Future<void> _handleSongCompletion() async {
    if (_isDisposed) return;

    switch (state.repeatMode) {
      case RepeatMode.off:
        if (state.currentIndex < state.queue.length - 1) {
          await skipNext();
        } else {
          state = state.copyWith(
              isPlaying: false,
              currentPosition: state.currentSong?.duration ?? Duration.zero);
        }
        break;
      case RepeatMode.all:
        if (state.currentIndex < state.queue.length - 1) {
          await skipNext();
        } else if (state.queue.isNotEmpty) {
          state = state.copyWith(currentIndex: 0);
          await _playCurrentSong(autoPlay: true);
        }
        break;
      case RepeatMode.one:
        await seekTo(Duration.zero);
        break;
    }
  }

  /// Load song by ID
  Future<Song> loadSongById(String songId) async {
    if (_isDisposed) throw Exception('Player is disposed');

    try {
      final pbService = PocketBaseService();
      final record = await pbService.pb.collection('songs').getOne(
            songId,
            expand: 'artist_id,album_id',
          );

      return Song.fromRecord(record);
    } catch (e) {
      debugPrint('Error loading song by ID: $e');
      throw Exception('Failed to load song: $e');
    }
  }

  /// Core play song method - completely simplified
  Future<void> playSong(Song song,
      {bool forceRestart = false, bool autoPlay = true}) async {
    if (_isDisposed || _isInitializing) return;

    try {
      final isCurrentSong = state.currentSong?.id == song.id;
      final shouldForceRestart = forceRestart || isCurrentSong;

      // Update state immediately
      state = state.copyWith(
        isBuffering: true,
        currentSong: song,
      );

      // Get audio URL
      final audioUrl = await _getSongAudioUrl(song);

      // Skip if same URL is already playing (unless forced restart)
      if (!shouldForceRestart &&
          _currentAudioUrl == audioUrl &&
          _audioPlayer.playing) {
        state = state.copyWith(isBuffering: false);
        return;
      }

      // Stop current playback
      try {
        await _audioPlayer.stop();
      } catch (e) {
        // Continue on stop errors
      }

      // Load new audio
      await _audioPlayer.setUrl(audioUrl);
      _currentAudioUrl = audioUrl;

      // Always play by default unless autoPlay is explicitly set to false
      if (autoPlay) {
        await _audioPlayer.play();
      }

      // Add to play history
      _addToPlayHistory(song.id);
    } catch (e) {
      debugPrint('Error playing song "${song.title}": $e');

      // Reset buffering state on error
      if (!_isDisposed) {
        state = state.copyWith(isBuffering: false);
      }
    }
  }

  /// Get song audio URL with fallback
  Future<String> _getSongAudioUrl(Song song) async {
    try {
      final pbService = PocketBaseService();
      final baseUrl = pbService.pb.baseUrl;

      if (song.audioFileName?.isNotEmpty == true) {
        return '$baseUrl/api/files/songs/${song.id}/${song.audioFileName}';
      } else {
        return '$baseUrl/api/files/songs/demo/dream_on_no3ma56xq7.mp3';
      }
    } catch (e) {
      debugPrint('Error getting song audio URL: $e, using fallback');
      return 'http://127.0.0.1:8090/api/files/songs/demo/dream_on_no3ma56xq7.mp3';
    }
  }

  /// Pause playback
  Future<void> pause() async {
    if (_isDisposed) return;
    try {
      await _audioPlayer.pause();
    } catch (e) {
      debugPrint('Error pausing playback: $e');
    }
  }

  /// Resume playback
  Future<void> resume() async {
    if (_isDisposed) return;
    try {
      await _audioPlayer.play();
    } catch (e) {
      debugPrint('Error resuming playback: $e');
    }
  }

  /// Toggle play/pause
  Future<void> togglePlayPause() async {
    if (_isDisposed) return;

    if (state.isPlaying) {
      await pause();
    } else {
      await resume();
    }
  }

  /// Skip to next - COMPLETELY SIMPLIFIED
  Future<void> skipNext() async {
    if (_isDisposed || _isInitializing) {
      return;
    }

    // Simple rate limiting - only prevent extremely rapid clicks
    final now = DateTime.now();
    if (_lastSkipTime != null &&
        now.difference(_lastSkipTime!) < _minSkipInterval) {
      return;
    }
    _lastSkipTime = now;

    try {
      final currentIndex = state.currentIndex;
      final queueLength = state.queue.length;

      if (queueLength == 0) return;

      int nextIndex;

      if (state.repeatMode == RepeatMode.one) {
        nextIndex = currentIndex;
      } else if (currentIndex < queueLength - 1) {
        nextIndex = currentIndex + 1;
      } else if (state.repeatMode == RepeatMode.all) {
        nextIndex = 0;
      } else {
        return; // End of queue
      }

      // Update index immediately
      state = state.copyWith(currentIndex: nextIndex);

      // Play the next song - ALWAYS autoPlay=true for skips
      await _playCurrentSong(autoPlay: true);
    } catch (e) {
      debugPrint('Error in skipNext: $e');
      if (!_isDisposed) {
        state = state.copyWith(isBuffering: false);
      }
    }
  }

  /// Skip to previous - COMPLETELY SIMPLIFIED
  Future<void> skipPrevious() async {
    if (_isDisposed || _isInitializing) {
      return;
    }

    // Simple rate limiting - only prevent extremely rapid clicks
    final now = DateTime.now();
    if (_lastSkipTime != null &&
        now.difference(_lastSkipTime!) < _minSkipInterval) {
      return;
    }
    _lastSkipTime = now;

    try {
      final currentIndex = state.currentIndex;
      final queueLength = state.queue.length;

      if (queueLength == 0) return;

      int prevIndex;

      if (state.repeatMode == RepeatMode.one) {
        prevIndex = currentIndex;
      } else if (currentIndex > 0) {
        prevIndex = currentIndex - 1;
      } else if (state.repeatMode == RepeatMode.all) {
        prevIndex = queueLength - 1;
      } else {
        return; // Beginning of queue
      }

      // Update index immediately
      state = state.copyWith(currentIndex: prevIndex);

      // Play the previous song - ALWAYS autoPlay=true for skips
      await _playCurrentSong(autoPlay: true);
    } catch (e) {
      debugPrint('Error in skipPrevious: $e');
      if (!_isDisposed) {
        state = state.copyWith(isBuffering: false);
      }
    }
  }

  /// Play the current song in the queue
  Future<void> _playCurrentSong({bool autoPlay = true}) async {
    if (state.queue.isEmpty ||
        state.currentIndex < 0 ||
        state.currentIndex >= state.queue.length) {
      return;
    }

    final currentSong = state.queue[state.currentIndex];
    await playSong(currentSong, autoPlay: autoPlay);
  }

  /// Seek to a position
  Future<void> seekTo(Duration position) async {
    if (_isDisposed) return;

    try {
      await _audioPlayer.seek(position);
      state = state.copyWith(currentPosition: position);
    } catch (e) {
      debugPrint('Error seeking to position: $e');
    }
  }

  /// Set queue and play with playlist context
  Future<void> playQueueFromPlaylist(
      List<Song> songs, int startIndex, String playlistId) async {
    if (_isDisposed) return;
    if (songs.isEmpty || startIndex < 0 || startIndex >= songs.length) return;

    final songToPlay = songs[startIndex];
    final isCurrentSong = state.currentSong?.id == songToPlay.id;
    final isDifferentContext = state.currentPlaylistId != playlistId;

    final shouldForceRestart = isCurrentSong && isDifferentContext;

    state = state.copyWith(
      queue: songs,
      currentIndex: startIndex,
      currentPlaylistId: playlistId,
    );

    // Always autoPlay=true when explicitly playing a queue
    await playSong(songToPlay,
        forceRestart: shouldForceRestart, autoPlay: true);
  }

  /// Set queue and play without playlist context
  Future<void> playQueue(List<Song> songs, int startIndex) async {
    if (_isDisposed) return;
    if (songs.isEmpty || startIndex < 0 || startIndex >= songs.length) return;

    final songToPlay = songs[startIndex];
    final isCurrentSong = state.currentSong?.id == songToPlay.id;
    final isDifferentContext = state.currentPlaylistId != null;

    final shouldForceRestart = isCurrentSong && isDifferentContext;

    state = state.copyWith(
      queue: songs,
      currentIndex: startIndex,
      currentPlaylistId: null,
    );

    // Always autoPlay=true when explicitly playing a queue
    await playSong(songToPlay,
        forceRestart: shouldForceRestart, autoPlay: true);
  }

  /// Toggle shuffle mode
  void toggleShuffle() {
    if (_isDisposed) return;

    final newShuffleMode = !state.shuffleMode;
    state = state.copyWith(shuffleMode: newShuffleMode);

    if (newShuffleMode) {
      if (state.currentPlaylistId != null && state.queue.isNotEmpty) {
        _shuffleCurrentQueue();
      } else {
        _shuffleAllSongs();
      }
    }
  }

  /// Shuffle current queue
  void _shuffleCurrentQueue() {
    if (state.queue.isEmpty) return;

    final currentSong = state.currentSong;
    final List<Song> shuffledQueue = List.from(state.queue)..shuffle();

    if (currentSong != null) {
      shuffledQueue.remove(currentSong);
      shuffledQueue.insert(0, currentSong);
    }

    state = state.copyWith(
      queue: shuffledQueue,
      currentIndex: 0,
    );
  }

  /// Shuffle all songs from database
  Future<void> _shuffleAllSongs() async {
    try {
      final songRepository = GetIt.instance<SongRepository>();
      final allSongs = await songRepository.getAllSongs();

      if (allSongs.isEmpty) return;

      final List<Song> shuffledSongs = List.from(allSongs)..shuffle();

      final currentSong = state.currentSong;
      int currentIndex = 0;

      if (currentSong != null) {
        shuffledSongs.removeWhere((song) => song.id == currentSong.id);
        shuffledSongs.insert(0, currentSong);
        currentIndex = 0;
      }

      state = state.copyWith(
        queue: shuffledSongs,
        currentIndex: currentIndex,
        currentPlaylistId: null,
      );
    } catch (e) {
      debugPrint('Error shuffling all songs: $e');
      if (state.queue.isNotEmpty) {
        _shuffleCurrentQueue();
      }
    }
  }

  /// Toggle repeat mode
  void toggleRepeatMode() {
    if (_isDisposed) return;

    switch (state.repeatMode) {
      case RepeatMode.off:
        state = state.copyWith(repeatMode: RepeatMode.all);
        break;
      case RepeatMode.all:
        state = state.copyWith(repeatMode: RepeatMode.one);
        break;
      case RepeatMode.one:
        state = state.copyWith(repeatMode: RepeatMode.off);
        break;
    }
  }

  /// Add song to queue
  void addToQueue(Song song) {
    if (_isDisposed) return;

    final newQueue = List<Song>.from(state.queue)..add(song);
    state = state.copyWith(queue: newQueue);
  }

  /// Remove song from queue
  void removeFromQueue(int index) {
    if (_isDisposed) return;

    if (index < 0 || index >= state.queue.length) return;

    final newQueue = List<Song>.from(state.queue)..removeAt(index);

    int newIndex = state.currentIndex;
    if (index < state.currentIndex) {
      newIndex--;
    } else if (index == state.currentIndex) {
      if (newQueue.isEmpty) {
        _audioPlayer.stop();
        state = state.copyWith(
          queue: newQueue,
          currentSong: null,
          isPlaying: false,
          currentIndex: -1,
        );
        return;
      }

      if (newIndex >= newQueue.length) {
        newIndex = newQueue.length - 1;
      }

      final newSong = newQueue[newIndex];

      state = state.copyWith(
        queue: newQueue,
        currentIndex: newIndex,
        currentSong: newSong,
      );

      // Always autoPlay=true when removing current song
      playSong(newSong, autoPlay: true);
      return;
    }

    state = state.copyWith(
      queue: newQueue,
      currentIndex: newIndex,
    );
  }

  void pauseSong() {
    if (_isDisposed) return;
    if (state.isPlaying) {
      state = state.copyWith(isPlaying: false);
    }
  }

  void resumeSong() {
    if (_isDisposed) return;
    if (!state.isPlaying && state.currentSong != null) {
      state = state.copyWith(isPlaying: true);
    }
  }

  /// Stop playback and reset player state
  Future<void> stopAndReset() async {
    if (_isDisposed) return;

    try {
      await _audioPlayer.stop();
      _currentAudioUrl = null;
      state = PlayerState.initial();
    } catch (e) {
      debugPrint('Error stopping and resetting player: $e');
      _currentAudioUrl = null;
      state = PlayerState.initial();
    }
  }

  void skipToNext() {
    if (_isDisposed) return;
    skipNext();
  }

  /// Add song to play history
  void _addToPlayHistory(String songId) {
    try {
      ref.read(playHistoryControllerProvider.notifier).addPlayHistory(songId);
    } catch (e) {
      debugPrint('Error adding to play history: $e');
    }
  }

  /// Debug helper
  void debugCurrentPlaylistId() {
    // Reduced debug logging for performance
  }

  /// Play song without playlist context
  Future<void> playSongWithoutPlaylist(Song song,
      {bool forceRestart = false}) async {
    if (_isDisposed) return;

    final isCurrentSong = state.currentSong?.id == song.id;
    final isDifferentContext = state.currentPlaylistId != null;

    final shouldForceRestart =
        forceRestart || isCurrentSong || (isCurrentSong && isDifferentContext);

    try {
      final songRepository = GetIt.instance<SongRepository>();
      final allSongs = await songRepository.getAllSongs();

      if (allSongs.isEmpty) {
        state = state.copyWith(
          queue: [song],
          currentIndex: 0,
          currentPlaylistId: null,
        );
      } else {
        final List<Song> shuffledSongs = List.from(allSongs)..shuffle();
        shuffledSongs.removeWhere((s) => s.id == song.id);
        shuffledSongs.insert(0, song);

        state = state.copyWith(
          queue: shuffledSongs,
          currentIndex: 0,
          currentPlaylistId: null,
          shuffleMode: true,
        );
      }
    } catch (e) {
      debugPrint('Error loading all songs for individual playback: $e');
      state = state.copyWith(
        queue: [song],
        currentIndex: 0,
        currentPlaylistId: null,
      );
    }

    // Always autoPlay=true when explicitly playing a song
    await playSong(song, forceRestart: shouldForceRestart, autoPlay: true);
  }

  /// Play song by ID without playlist context
  Future<void> playSongByIdWithoutPlaylist(String songId) async {
    if (_isDisposed) return;

    try {
      SongRepository.clearCache();

      final songRepository = GetIt.instance<SongRepository>();
      final song = await songRepository.getSongById(songId);

      if (song == null) {
        if (!_isDisposed) {
          state = state.copyWith(isBuffering: false);
        }
        return;
      }

      await playSongWithoutPlaylist(song);
    } catch (e) {
      debugPrint('Error loading song by ID: $e');
      if (!_isDisposed) {
        state = state.copyWith(isBuffering: false);
      }
    }
  }

  /// Update queue and index
  void updateQueue(List<Song> newQueue, int newIndex) {
    if (_isDisposed) return;

    if (newIndex < 0 || newIndex >= newQueue.length) return;

    final newCurrentSong = newQueue[newIndex];

    state = state.copyWith(
      queue: newQueue,
      currentIndex: newIndex,
      currentSong: newCurrentSong,
    );
  }

  /// Load and shuffle all songs
  Future<void> loadAllSongsAndShuffle() async {
    if (_isDisposed) return;

    try {
      final songRepository = GetIt.instance<SongRepository>();
      final allSongs = await songRepository.getAllSongs();

      if (allSongs.isEmpty) return;

      final List<Song> shuffledSongs = List.from(allSongs)..shuffle();

      final currentSong = state.currentSong;
      int currentIndex = 0;

      if (currentSong != null) {
        shuffledSongs.removeWhere((song) => song.id == currentSong.id);
        shuffledSongs.insert(0, currentSong);
        currentIndex = 0;
      }

      state = state.copyWith(
        queue: shuffledSongs,
        currentIndex: currentIndex,
        currentPlaylistId: null,
        shuffleMode: true,
      );
    } catch (e) {
      debugPrint('Error loading and shuffling all songs: $e');
    }
  }
}
